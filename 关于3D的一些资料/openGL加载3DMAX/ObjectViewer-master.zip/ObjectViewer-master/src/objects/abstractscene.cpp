#include "abstractscene.h"

AbstractScene::AbstractScene(QObject* parent) : QObject(parent) {}
