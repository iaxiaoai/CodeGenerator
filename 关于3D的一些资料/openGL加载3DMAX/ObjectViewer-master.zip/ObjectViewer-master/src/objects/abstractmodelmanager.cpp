#include "abstractmodelmanager.h"

AbstractModelManager::AbstractModelManager() {}
AbstractModelManager::~AbstractModelManager() {}
