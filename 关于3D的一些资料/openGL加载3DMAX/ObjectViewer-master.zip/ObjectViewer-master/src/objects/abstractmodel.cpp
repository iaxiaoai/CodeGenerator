#include "abstractmodel.h"

AbstractModel::AbstractModel() {}
AbstractModel::~AbstractModel() {}
