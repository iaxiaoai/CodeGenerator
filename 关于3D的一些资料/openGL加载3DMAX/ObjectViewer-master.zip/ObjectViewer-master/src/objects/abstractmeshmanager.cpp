#include "abstractmeshmanager.h"

AbstractMeshManager::AbstractMeshManager() {}
AbstractMeshManager::~AbstractMeshManager() {}
