#include "abstracttexturemanager.h"

AbstractTextureManager::AbstractTextureManager() {}
AbstractTextureManager::~AbstractTextureManager() {}
