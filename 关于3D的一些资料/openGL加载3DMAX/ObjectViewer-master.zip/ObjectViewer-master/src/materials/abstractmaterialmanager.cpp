#include "abstractmaterialmanager.h"

AbstractMaterialManager::AbstractMaterialManager() {}
AbstractMaterialManager::~AbstractMaterialManager() {}
