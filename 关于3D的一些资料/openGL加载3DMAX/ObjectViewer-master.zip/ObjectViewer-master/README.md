ObjectViewer
============

### Linux

![ObjectViewer](http://image.noelshack.com/fichiers/2013/48/1385350699-objectviewer-linux.png "ObjectViewer")

![ObjectViewer](http://image.noelshack.com/fichiers/2014/05/1391282727-objectviewer-linux-transparency.png "ObjectViewer")

### Windows

![ObjectViewer](http://image.noelshack.com/fichiers/2013/47/1385230953-objectviewer.png "ObjectViewer")

![ObjectViewer](http://image.noelshack.com/fichiers/2013/47/1385230953-objctviewer-wireframe.png "ObjectViewer")
