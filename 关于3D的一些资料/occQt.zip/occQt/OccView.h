/*
*    Copyright (c) 2014 eryar All Rights Reserved.
*
*           File : OccView.h
*         Author : eryar@163.com
*           Date : 2014-07-15 21:00
*        Version : 1.0v
*
*    Description : Adapte OpenCASCADE view for Qt.
*                  
*/

#ifndef _OCCVIEW_H_
#define _OCCVIEW_H_

#include <QtOpenGL\QGLWidget>

#ifndef WNT
    #define WNT
#endif 

#include <AIS_InteractiveContext.hxx>
#include <V3d_Viewer.hxx>
#include <V3d_View.hxx>
//#include <Graphic3d_WNTGraphicDevice.hxx>
#include <Aspect_Handle.hxx>

class QMenu;
class QRubberBand;

class COccView : public QGLWidget
{
    Q_OBJECT

public:
    enum CurrentAction3d 
    { 
        CurAction3d_Nothing, 
        CurAction3d_DynamicZooming,
        CurAction3d_WindowZooming, 
        CurAction3d_DynamicPanning,
        CurAction3d_GlobalPanning, 
        CurAction3d_DynamicRotation 
    };

public:
    COccView(Handle_AIS_InteractiveContext theContext, QWidget* parent);

signals:
    void selectionChanged(void);

public slots:
    void pan(void);
    void fitAll(void);
    void reset(void);
    void zoom(void);
    void rotate(void);

protected:
    // Paint events.
    virtual void paintEvent(QPaintEvent* e);
    virtual void resizeEvent(QResizeEvent* e);

    // Mouse events.
    virtual void mousePressEvent(QMouseEvent* e);
    virtual void mouseReleaseEvent(QMouseEvent* e);
    virtual void mouseMoveEvent(QMouseEvent * e);
    virtual void wheelEvent(QWheelEvent * e);

    // Button events.
    virtual void onLButtonDown(const int nFlags, const QPoint point);
    virtual void onMButtonDown(const int nFlags, const QPoint point);
    virtual void onRButtonDown(const int nFlags, const QPoint point);
    virtual void onMouseWheel(const int nFlags, const int zDelta, const QPoint point);
    virtual void onLButtonUp(const int nFlags, const QPoint point);
    virtual void onMButtonUp(const int nFlags, const QPoint point);
    virtual void onRButtonUp(const int nFlags, const QPoint point);
    virtual void onMouseMove(const int nFlags, const QPoint point);
    
    // Popup menu.
    virtual void addItemInPopup(QMenu* menu);

protected:
    void popup(const int x, const int y);
    void dragEvent(const int x, const int y);
    void inputEvent(const int x, const int y);
    void moveEvent(const int x, const int y);
    void multiMoveEvent(const int x, const int y);
    void multiDragEvent(const int x, const int y);
    void multiInputEvent(const int x, const int y);
    void drawRubberBand(const int minX, const int minY, const int maxX, const int maxY);
    void panByMiddleButton(const QPoint& point);

private:

    Handle_V3d_View myView;

    Handle_AIS_InteractiveContext myContext;

    Standard_Integer myXmin;
    Standard_Integer myYmin;
    Standard_Integer myXmax;
    Standard_Integer myYmax;

    CurrentAction3d myCurrentMode;

    Standard_Boolean myDegenerateModeIsOn;

    QRubberBand* myRectBand;

};

#endif // _OCCVIEW_H_
