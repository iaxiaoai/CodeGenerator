
#include "OccView.h"

#include <QMenu>
#include <QMouseEvent>
#include <QRubberBand>
#include <QStyleFactory>

// occ header files.
#include <WNT_Window.hxx>


// the key for multi selection :
#define MULTISELECTIONKEY Qt::ShiftModifier

// the key for shortcut ( use to activate dynamic rotation, panning )
#define CASCADESHORTCUTKEY Qt::ControlModifier


COccView::COccView( Handle_AIS_InteractiveContext theContext, QWidget* parent )
    : QGLWidget(parent),
    myContext(theContext),
    myXmin(0),
    myXmax(0),
    myYmin(0),
    myYmax(0),
    myDegenerateModeIsOn(Standard_True),
    myCurrentMode(CurAction3d_DynamicRotation),
    myRectBand(NULL)
{
    // Create the view.
    myView = theContext->CurrentViewer()->CreateView();

    // Attaching the window to the view.
    // Portable in principle, but if you use it you are probably about to do something
    // non-portable. Be careful. Gets the window system identifier of the widget by winId().
    HWND winID = (HWND) (winId());
    Handle_WNT_Window hWnd = new WNT_Window(winID);
    myView->SetWindow(hWnd);
    if (!hWnd->IsMapped())
    {
        hWnd->Map();
    }
    
    myView->SetBackgroundColor(Quantity_NOC_BLACK);
    myView->MustBeResized();
    myView->TriedronDisplay(Aspect_TOTP_LEFT_LOWER, Quantity_NOC_GOLD, 0.1, V3d_ZBUFFER);

    // Enable the mouse tracking, by default the mouse tracking is disabled.
    setMouseTracking( true );
}

void COccView::paintEvent( QPaintEvent* e )
{
    myView->Redraw();
}

void COccView::resizeEvent( QResizeEvent* e )
{
    if( !myView.IsNull() )
    {
        myView->MustBeResized();
    }
}

void COccView::fitAll( void )
{
    myView->FitAll();
    myView->ZFitAll();
    myView->Redraw();
}

void COccView::reset( void )
{
    myView->Reset();
}

void COccView::pan( void )
{
    myCurrentMode = CurAction3d_DynamicPanning;
}

void COccView::zoom( void )
{
    myCurrentMode = CurAction3d_DynamicZooming;
}

void COccView::rotate( void )
{
    myCurrentMode = CurAction3d_DynamicRotation;
}


void COccView::mousePressEvent( QMouseEvent* e )
{
    if (e->button() == Qt::LeftButton)
    {
        onLButtonDown((e->buttons() | e->modifiers()), e->pos());
    }
    else if (e->button() == Qt::MidButton)
    {
        onMButtonDown((e->buttons() | e->modifiers()), e->pos());
    }
    else if (e->button() == Qt::RightButton)
    {
        onRButtonDown((e->buttons() | e->modifiers()), e->pos());
    }
}

void COccView::mouseReleaseEvent( QMouseEvent* e )
{
    if (e->button() == Qt::LeftButton)
    {
        onLButtonUp(e->buttons() | e->modifiers(), e->pos());
    }
    else if (e->button() == Qt::MidButton)
    {
        onMButtonUp(e->buttons() | e->modifiers(), e->pos());
    }
    else if (e->button() == Qt::RightButton)
    {
        onRButtonUp(e->buttons() | e->modifiers(), e->pos());
    }
}

void COccView::mouseMoveEvent( QMouseEvent * e )
{
    onMouseMove(e->buttons(), e->pos());
}

void COccView::wheelEvent( QWheelEvent * e )
{
    onMouseWheel(e->buttons(), e->delta(), e->pos());
}

void COccView::onLButtonDown( const int nFlags, const QPoint point )
{
    // Save the current mouse coordinate in min.
    myXmin = point.x();
    myYmin = point.y();
    myXmax = point.x();
    myYmax = point.y();

}

void COccView::onMButtonDown( const int nFlags, const QPoint point )
{
    // Save the current mouse coordinate in min.
    myXmin = point.x();
    myYmin = point.y();
    myXmax = point.x();
    myYmax = point.y();

    if (myCurrentMode == CurAction3d_DynamicRotation)
    {
        myView->StartRotation(point.x(), point.y());
    }
}

void COccView::onRButtonDown( const int nFlags, const QPoint point )
{
    
}

void COccView::onMouseWheel( const int nFlags, const int zDelta, const QPoint point )
{
    Standard_Integer factor = 16;

    Standard_Integer xPos = point.x();
    Standard_Integer yPos = point.y();

    if (zDelta > 0)
    {
        xPos += factor;
        yPos += factor;
    }
    else
    {
        xPos -= factor;
        yPos -= factor;
    }

    myView->Zoom(point.x(), point.y(), xPos, yPos);
}

void COccView::addItemInPopup( QMenu* menu )
{

}

void COccView::popup( const int x, const int y )
{

}

void COccView::onLButtonUp( const int nFlags, const QPoint point )
{
    // Hide the QRubberBand
    if (myRectBand)
    {
        myRectBand->hide();
    }

    // Ctrl for multi selection.
    if (point.x() == myXmin && point.y() == myYmin)
    {
        if (nFlags & Qt::ControlModifier)
        {
            multiInputEvent(point.x(), point.y());
        }
        else
        {
            inputEvent(point.x(), point.y());
        }
    }
    
}

void COccView::onMButtonUp( const int nFlags, const QPoint point )
{
    if (point.x() == myXmin && point.y() == myYmin)
    {
        panByMiddleButton(point);
    }
}

void COccView::onRButtonUp( const int nFlags, const QPoint point )
{
    popup(point.x(), point.y());
}

void COccView::onMouseMove( const int nFlags, const QPoint point )
{
    // Draw the rubber band.
    if (nFlags & Qt::LeftButton)
    {
        drawRubberBand(myXmin, myYmin, point.x(), point.y());

        dragEvent(point.x(), point.y());
    }

    // Ctrl for multi selection.
    if (nFlags & Qt::ControlModifier)
    {
        multiMoveEvent(point.x(), point.y());
    }
    else
    {
        moveEvent(point.x(), point.y());
    }

    // Middle button.
    if (nFlags & Qt::MidButton)
    {
        switch (myCurrentMode)
        {
        case CurAction3d_DynamicRotation:
            myView->Rotation(point.x(), point.y());
            break;

        case CurAction3d_DynamicZooming:
            myView->Zoom(myXmin, myYmin, point.x(), point.y());
            break;

        case CurAction3d_DynamicPanning:
            myView->Pan(point.x() - myXmax, myYmax - point.y());
            myXmax = point.x();
            myYmax = point.y();
            break;
        }
    }

}

void COccView::dragEvent( const int x, const int y )
{
    myContext->Select( myXmin, myYmin, x, y, myView );

    emit selectionChanged();
}

void COccView::multiDragEvent( const int x, const int y )
{
    myContext->ShiftSelect( myXmin, myYmin, x, y, myView );

    emit selectionChanged();

}

void COccView::inputEvent( const int x, const int y )
{
    myContext->Select();

    emit selectionChanged();
}

void COccView::multiInputEvent( const int x, const int y )
{
    myContext->ShiftSelect();

    emit selectionChanged();
}

void COccView::moveEvent( const int x, const int y )
{
    myContext->MoveTo(x, y, myView);
}

void COccView::multiMoveEvent( const int x, const int y )
{
    myContext->MoveTo(x, y, myView);
}

void COccView::drawRubberBand( const int minX, const int minY, const int maxX, const int maxY )
{
    QRect aRect;

    // Set the rectangle correctly.
    (minX < maxX) ? (aRect.setX(minX)) : (aRect.setX(maxX));
    (minY < maxY) ? (aRect.setY(minY)) : (aRect.setY(maxY));

    aRect.setWidth(abs(maxX - minX));
    aRect.setHeight(abs(maxY - minY));

    if (!myRectBand)
    {
        myRectBand = new QRubberBand(QRubberBand::Rectangle, this);

        // setStyle is important, set to windows style will just draw
        // rectangle frame, otherwise will draw a solid rectangle.
        myRectBand->setStyle(QStyleFactory::create("windows"));
    }

    myRectBand->setGeometry(aRect);
    myRectBand->show();
}

void COccView::panByMiddleButton( const QPoint& point )
{
    Standard_Integer xCenter = 0;
    Standard_Integer yCenter = 0;

    QSize rectSize = size();

    xCenter = size().width() / 2;
    yCenter = size().height() / 2;

    myView->Pan(xCenter - point.x(), point.y() - yCenter);
}
