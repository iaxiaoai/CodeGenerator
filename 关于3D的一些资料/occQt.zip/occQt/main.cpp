/*
*    Copyright (c) 2014 eryar All Rights Reserved.
*
*           File : main.cpp
*         Author : eryar@163.com
*           Date : 2014-07-15 21:00
*        Version : 1.0v
*
*    Description : OpenCASCADE with Qt demo.
*                  
*/

#include "occQt.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    occQt w;
    w.show();
    
    return a.exec();
}
