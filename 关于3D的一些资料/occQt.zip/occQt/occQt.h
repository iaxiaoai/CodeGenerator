/*
*    Copyright (c) 2014 eryar All Rights Reserved.
*
*           File : occQt.h
*         Author : eryar@163.com
*           Date : 2014-07-15 21:00
*        Version : 1.0v
*
*    Description : OpenCASCADE with Qt demo.
*                  
*/

#ifndef OCCQT_H
#define OCCQT_H

#include <QtWidgets/QMainWindow>
#include "ui_occqt.h"

#include "OccView.h"

class occQt : public QMainWindow
{
    Q_OBJECT

public:
    occQt(QWidget *parent = 0);
    ~occQt();

protected:
    

private:
    void createActions(void);
    void createMenus(void);
    void createToolBars(void);

    // occ
    void InitializeModeler(void);

private slots:
    void about(void);
    void makeBox(void);
    void makeCone(void);
    void makeSphere(void);
    void transform(void);

private:
    Ui::occQtClass ui;

private:
    QAction* exitAction;

    QAction* viewPanAction;
    QAction* viewResetAction;
    QAction* viewFitallAction;

    QAction* makeBoxAction;
    QAction* makeConeAction;
    QAction* makeSphereAction;
    QAction* transformAction;

    QAction* aboutAction;

    QMenu* fileMenu;
    QMenu* viewMenu;
    QMenu* primitivesMenu;
    QMenu* helpMenu;

    QToolBar* fileToolBar;
    QToolBar* viewToolBar;
    QToolBar* primitivesToolBar;
    QToolBar* helpToolBar;

    // Open Cascade
    COccView* myOccView;
    Handle_V3d_Viewer myViewer;
    //Handle_Graphic3d_WNTGraphicDevice myGraphicDevice;
    Handle_AIS_InteractiveContext myContext;

};

#endif // OCCQT_H
