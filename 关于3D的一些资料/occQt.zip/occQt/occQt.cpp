/*
*    Copyright (c) 2013 eryar All Rights Reserved.
*
*        File    : occqt.cpp
*        Author  : eryar@163.com
*        Date    : 2013-03-18 20:29
*        Version : V1.0
*
*    Description : 
*                  
*
*/

#include "occqt.h"

#include <QTreeView>
#include <QMessageBox>
#include <QDockWidget>

#include <AIS_Shape.hxx>
#include <TopoDS.hxx>
#include <TopExp_Explorer.hxx>
#include <TColgp_Array1OfPnt2d.hxx>

#include <BRepPrimAPI_MakeBox.hxx>
#include <BRepPrimAPI_MakeCone.hxx>
#include <BRepPrimAPI_MakeSphere.hxx>
#include <BRepFilletAPI_MakeFillet.hxx>
#include <BRepFilletAPI_MakeFillet2d.hxx>
#include <BRepBuilderAPI_Transform.hxx>

#include <Graphic3d.hxx>
#include <Aspect_DisplayConnection.hxx>

occQt::occQt(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);

    // occ modeler.
    InitializeModeler();

    myOccView = new COccView(myContext, this);
    setCentralWidget(myOccView);

    createActions();
    createMenus();
    createToolBars();
}

occQt::~occQt()
{

}

void occQt::createActions( void )
{
    exitAction = new QAction(tr("Exit"), this);
    exitAction->setShortcut(tr("Ctrl+Q"));
    exitAction->setIcon(QIcon(":/Resources/close.png"));
    exitAction->setStatusTip(tr("Exit the application"));
    connect(exitAction, SIGNAL(triggered()), this, SLOT(close()));

    viewPanAction = new QAction(tr("Pan"), this);
    viewPanAction->setIcon(QIcon(":/Resources/view_pan.png"));
    viewPanAction->setStatusTip(tr("Pan the view"));
    connect(viewPanAction, SIGNAL(triggered()), myOccView, SLOT(pan()));

    viewResetAction = new QAction(tr("Reset"), this);
    viewResetAction->setIcon(QIcon(":/Resources/view_reset.png"));
    viewResetAction->setStatusTip(tr("Reset the view"));
    connect(viewResetAction, SIGNAL(triggered()), myOccView, SLOT(reset()));

    viewFitallAction = new QAction(tr("Fit all"), this);
    viewFitallAction->setIcon(QIcon(":/Resources/view_fitall.png"));
    viewFitallAction->setStatusTip(tr("Fit all "));
    connect(viewFitallAction, SIGNAL(triggered()), myOccView, SLOT(fitAll()));

    makeBoxAction = new QAction(tr("Box"), this);
    makeBoxAction->setStatusTip(tr("Make a box"));
    connect(makeBoxAction, SIGNAL(triggered()), this, SLOT(makeBox()));

    makeConeAction = new QAction(tr("Cone"), this);
    makeConeAction->setStatusTip(tr("Make a cone"));
    connect(makeConeAction, SIGNAL(triggered()), this, SLOT(makeCone()));

    makeSphereAction = new QAction(tr("Sphere"), this);
    makeSphereAction->setStatusTip(tr("Make a sphere"));
    connect(makeSphereAction, SIGNAL(triggered()), this, SLOT(makeSphere()));

    transformAction = new QAction(tr("Transform"), this);
    transformAction->setStatusTip(tr("Transformation"));
    connect(transformAction, SIGNAL(triggered()), this, SLOT(transform()));

    aboutAction = new QAction(tr("About"), this);
    aboutAction->setIcon(QIcon(":/occQt/Resources/help.png"));
    aboutAction->setStatusTip(tr("About the application"));
    connect(aboutAction, SIGNAL(triggered()), this, SLOT(about()));
}

void occQt::createMenus( void )
{
    fileMenu = menuBar()->addMenu(tr("&File"));
    fileMenu->addAction(exitAction);

    viewMenu = menuBar()->addMenu(tr("&View"));
    viewMenu->addAction(viewPanAction);
    viewMenu->addAction(viewResetAction);
    viewMenu->addAction(viewFitallAction);

    primitivesMenu = menuBar()->addMenu(tr("Primitive"));
    primitivesMenu->addAction(makeBoxAction);
    primitivesMenu->addAction(makeConeAction);
    primitivesMenu->addAction(makeSphereAction);
    primitivesMenu->addAction(transformAction);

    helpMenu = menuBar()->addMenu(tr("Help"));
    helpMenu->addAction(aboutAction);
}

void occQt::createToolBars( void )
{
    fileToolBar = addToolBar(tr("&File"));
    fileToolBar->addAction(exitAction);

    viewToolBar = addToolBar(tr("&View"));
    viewToolBar->addAction(viewPanAction);
    viewToolBar->addAction(viewResetAction);
    viewToolBar->addAction(viewFitallAction);

    primitivesToolBar = addToolBar(tr("&Primitive"));
    primitivesToolBar->addAction(makeBoxAction);
    primitivesToolBar->addAction(makeConeAction);
    primitivesToolBar->addAction(makeSphereAction);
    primitivesToolBar->addAction(transformAction);

    helpToolBar = addToolBar(tr("Help"));
    helpToolBar->addAction(aboutAction);
}

void occQt::about( void )
{
    QMessageBox::about(this, tr("About occQt"),
        tr("<h2>occQt 2.0</h2>"
        "<p>Copyright &copy; 2014 eryar@163.com"
        "<p>occQt is a demo applicaton about Qt and OpenCASCADE."));
}

void occQt::InitializeModeler( void )
{
    Handle_Aspect_DisplayConnection displayConnection;
    Handle_Graphic3d_GraphicDriver graphicDriver;

    // 1. Create a 3D viewer.
    try
    {
        //myGraphicDevice = new Graphic3d_WNTGraphicDevice;
        graphicDriver = Graphic3d::InitGraphicDriver(displayConnection);
    }
    catch (Standard_Failure)
    {
        QMessageBox::critical(this, tr("About occQt"),
            tr("<h2>Fatal error in graphic initialisation!</h2>"),
            QMessageBox::Apply);
    }

    myViewer = new V3d_Viewer(graphicDriver, Standard_ExtString("Visu3D"));
    //myViewer->Init();
    myViewer->SetDefaultLights();
    myViewer->SetLightOn();

    // 3. Create an interactive context.
    myContext = new AIS_InteractiveContext(myViewer);
    myContext->SetDisplayMode(AIS_Shaded);
}

void occQt::makeBox( void )
{
    TopoDS_Shape theBox = BRepPrimAPI_MakeBox(100, 60, 80);
    BRepFilletAPI_MakeFillet MF(theBox);

    // Add all the edges to fillet.
    for (TopExp_Explorer ex(theBox, TopAbs_EDGE); ex.More(); ex.Next())
    {
        MF.Add(10, TopoDS::Edge(ex.Current()));
    }

    Handle_AIS_Shape aBox = new AIS_Shape(MF.Shape());
    myContext->Display(aBox);
}

void occQt::makeCone( void )
{
    Handle_AIS_Shape aCone = new AIS_Shape(BRepPrimAPI_MakeCone(50, 30, 80));
    myContext->Display(aCone);
}

void occQt::makeSphere( void )
{
    Handle_AIS_Shape aSphere = new AIS_Shape(BRepPrimAPI_MakeSphere(60));
    myContext->Display(aSphere);
}

void occQt::transform()
{
    TopoDS_Shape aBox = BRepPrimAPI_MakeBox(gp_Pnt(30.0, 30.0, 30.0), gp_Pnt(50.0, 50.0, 50.0));
    TopoDS_Shape aSphere = BRepPrimAPI_MakeSphere(10.0);

    for (Standard_Integer i = 1; i <= 12; ++i)
    {
        gp_Trsf aTrsf;

        aTrsf.SetRotation(gp::OZ(), i * M_PI / 6);

        BRepBuilderAPI_Transform aTransformAlgo(aTrsf);

        aTransformAlgo.Perform(aBox, Standard_True);

        if (aTransformAlgo.IsDone())
        {
            Handle_AIS_Shape aAisShape = new AIS_Shape(aTransformAlgo.Shape());
            aAisShape->SetColor(Quantity_Color(i%3*0.1, i%2, i%3*0.1, Quantity_TOC_RGB));

            myContext->Display(aAisShape, Standard_False);
        }
    }

    myContext->Display(new AIS_Shape(aSphere));
}